import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import {  Router } from '@angular/router';
@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
passwordFieldType: string = 'password';
formData = {
  email: '',
  password: ''
}
submit = true;
constructor(private http: HttpClient, private router: Router) { }

  ngOnInit(): void {
  }
  
togglePasswordVisibility() {
  this.passwordFieldType = this.passwordFieldType === 'password' ? 'text' : 'password';
}
  onsubmit() {
    this.http.get<any>("http://localhost:3000/sigupUsers")
      .subscribe(res => {
        console.log(res);
        const user = res.find((a: any) => {
          return a.email === this.formData.email && a.password === this.formData.password;
        });
        if (user) {
          sessionStorage.setItem('LoginuserDetails', JSON.stringify(user));
          this.router.navigate(['./dashboard']);
        } else {
          alert("User not found");
        }
      }, err => {
        alert("Something went wrong");
      });
    }
  }



      

      
      
        
    
      
