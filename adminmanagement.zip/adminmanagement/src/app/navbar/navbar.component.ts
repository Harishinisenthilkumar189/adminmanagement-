import { Component, OnInit } from '@angular/core';
import { AuthService } from '../_services/auth.service';
@Component({
  selector: 'app-navbar',
  standalone: false,
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent implements OnInit{
onsubmit() {
throw new Error('Method not implemented.');
}
submit: any;
formData: any;
loginuseData: any;  
  constructor(public auth:AuthService){}
  ngOnInit(): void {
    const currentUser = sessionStorage.getItem('LoginuserDetails');
    this.loginuseData = JSON.parse(currentUser? currentUser : "empty");  
  }
}
