import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
 
@Injectable({
  providedIn: 'root'
})
export class AuthService {
 
  constructor(private router:Router) { }
 
  isAuthendicated():boolean{
    if (sessionStorage.getItem('token') !== null) {
      return true;
    }
    return false;
  }
 

}