import { Component, OnInit } from '@angular/core';
import { AuthService } from '../_services/auth.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
@Component({
  selector: 'app-dashboard',
  standalone: false,
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit {
userData: any;
item: any;
username: any;
loginuseData: any;
  constructor(private auth:AuthService,private http:HttpClient,private router:Router) { }
  ngOnInit(): void {
   this.http.get<any>("http://localhost:3000/sigupUsers")
   .subscribe(res=>{
     this.userData =  res;  
     const currentUser = sessionStorage.getItem('LoginuserDetails');
     this.loginuseData = JSON.parse(currentUser? currentUser : "empty");     
   })
  }
  deleteDetails(id:any){
    this.http.delete<any>(`http://localhost:3000/sigupUsers/` + id)
     .subscribe(res=>{
     this.userData =  this.userData.filter((_: { id: number; }) =>_.id != id);  
     alert("user deleted successfully");
   })
  }
}