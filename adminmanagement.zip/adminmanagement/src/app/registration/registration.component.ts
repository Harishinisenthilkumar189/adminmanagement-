import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
 
 
@Component({
  selector: 'app-registeration',
  standalone: false,
  templateUrl: './registration.component.html',
  styleUrl: './registration.component.css'
})
export class RegisterationComponent implements OnInit{

  passwordFieldType: string = 'password';

togglePasswordVisibility() {
  this.passwordFieldType = this.passwordFieldType === 'password' ? 'text' : 'password';
}
  constructor(private http: HttpClient, private router: Router) {}
 
  formData = {
    name: '',
    email: '',
    role: '',
    password: '',
    department: '',
    dob:'',
    address:'',
    pincode:'',
    phone:'',
 
  }
  submit=false;
  ngOnInit(): void {
  
  }
  onsubmit(){
    debugger;
    console.log('form data', this.formData);
    this.http.post<any>("http://localhost:3000/sigupUsers", this.formData )
    .subscribe(res=> {
      alert("sign form successfully");
      // this.formData = {};
      this.router.navigate(['./login'])
    },err=>{
      alert('something went wrong');
    })
  }
 
  onClear() {
    this.formData = {
      name: '',
      email: '',
      role: '',
      password: '',
      department: '',
      dob:'',
      address:'',
      pincode:'',
      phone:'',
   
    }
  }
}



